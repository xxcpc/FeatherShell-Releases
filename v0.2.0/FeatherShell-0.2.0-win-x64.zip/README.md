# FeatherShell

一个自研 Windows SSH 终端。用户在本地登录，AI 通过临时目标引用执行受控诊断。

**0.2.0 Preview** 对应内网方案的第一批 P0 功能。通过本地 SSH 管理连接，在任务中心追踪只读诊断，在软件方案库导入和校验离线方案。

## 开始使用

解压完整发行包后启动 `FeatherShell.exe`。不要单独移动 exe；Broker、Agent 和 Terminal 文件夹均为运行必需。

- Windows x64，需 Microsoft Edge WebView2 Runtime。
- 默认发行包需 .NET 10 Desktop Runtime；构建时使用 `-SelfContained` 可随包包含 .NET Runtime。
- 点击“新建连接”，输入地址、账号、密码，或选择私钥文件路径。私钥带口令时在密码框输入口令。
- 首次连接必须人工通过可信渠道核对 SSH 主机指纹。主机密钥变化时阻止连接，不自动覆盖。
- 左侧按钮切换连接；终端输入是用户的手工操作，权限等同于 SSH 登录账号。
- 勾选连接后，点击“本地只读巡检”，无需配置模型即可查询系统与资源摘要。
- 使用“模型设置”填写 HTTPS 的 OpenAI 兼容 Chat Completions 完整地址、模型 ID 和模型 API Key，再开始自然语言诊断。
- 问题和结构化工具结果会发送给配置的模型服务；模型 API Key 也会按协议用于该服务的认证。连接账号、密码和地址不作为模型配置或工具参数发送。
- 每次任务结束会取消勾选并撤销授权；中途取消勾选会停止任务。

多个已连接目标可以共同参与同一诊断任务。当前串行执行；目标各自持有授权引用。后续可在此基础上增加依赖图、分批变更和并发调度。

工具栏的“任务中心”显示本地巡检与 AI 诊断的时间、目标数量、查询结果计数和结束状态。任务 ID 可用于在本地审计文件中关联授权与工具调用。程序意外退出时，未完成的任务会显示为“上次运行未记录完成”。

## 离线软件方案

在“软件方案库”选择 ZIP 文件导入。同一软件的不同版本可以共存。相同版本只能重新导入完全相同的 ZIP。库内条目在读取时重新检查包内文件的 SHA256，校验结果只说明文件与包内清单一致，不能证明发布者身份。

ZIP 根目录使用 `manifest.json`，也可使用包含 JSON 语法的 `manifest.yaml`。首版支持清单格式版本 1。每个包内文件都必须列在 `files`，路径区分大小写，使用正斜杠。清单本身不列入文件列表。六个阶段依次为 `precheck`、`install`、`configure`、`start`、`verify`、`rollback`，各自引用一个已登记的文件。ZIP 包无需添加显式文件夹条目。

```json
{
  "schemaVersion": 1,
  "software": "nginx",
  "version": "1.2.3",
  "os": ["linux"],
  "architectures": ["x86_64"],
  "dependencies": ["systemd"],
  "permissions": ["service-admin"],
  "variables": [{"name": "HTTP_PORT", "required": true, "secret": false}],
  "files": [
    {"path": "scripts/precheck.sh", "sha256": "<该文件的 64 位十六进制 SHA256>"}
  ],
  "steps": [
    {"phase": "precheck", "file": "scripts/precheck.sh"}
  ]
}
```

示例只列出第一个阶段。制作实际方案包时补齐其余五个阶段及其文件和哈希。可用 PowerShell 的 `Get-FileHash -Algorithm SHA256` 计算哈希。导入和浏览过程只读取并校验包内数据，不运行脚本。

## 已实现的 AI 工具

| 动作 | 返回内容 | 限制 |
|---|---|---|
| system_summary | 发行版类别、架构类别 | 固定枚举，不返回主机名或原始文件 |
| resource_summary | 内存总量、可用内存、1 分钟负载 | 仅数值；load1 不是 CPU 使用率 |
| service_status | active/inactive/failed 等状态 | 仅 nginx、redis、docker、postgresql |

AI 不支持任意 Shell、原始日志读取、SFTP、安装、重启、sudo、创建连接。需要这些动作时用户仍可手工使用终端。服务 unit 名尚不支持发行版别名映射。

## 架构

```
FeatherShell.App       本地可信桌面控制器、连接表单、xterm/WebView2、任务编排
  ├─ Broker           SSH.NET 连接、ShellStream、独立 exec channel、主机指纹、授权与审计
  └─ Agent            单次模型决策工作进程，仅接收模型配置、问题、临时目标、结构化结果
FeatherShell.Contracts 共享协议和动作白名单；没有 SSH 引用
FeatherShell.Tests     本机模拟 SSH 集成测试
```

App 通过重定向的标准输入输出与子进程通信，不开放本地监听端口。Agent 没有 Broker 的控制通道。终端静态资源随包离线分发，禁止外部导航和资源请求。

AI 当前通过兼容 HTTP API 调用；MCP 适配层尚未实现。优先验证安全工具边界，后续可在该边界外增加 MCP Server，不应暴露 Broker 的连接与手工终端接口。

## 本地数据

`%LOCALAPPDATA%/FeatherShell/` 保存：

- `known-hosts.json`：地址与端口的散列索引、主机公钥指纹。散列不是加密，不能认为地址因此无法被猜测。
- `audit.jsonl`：授权与工具执行的结构化记录。不保存账号、密码、地址、原始命令输出或聊天内容。
- `tasks/`：诊断任务状态、计数和审计关联 ID。
- `packages/`：导入的原始 ZIP 方案包。
- `WebView/`：本地终端浏览器运行数据，不启用密码保存和自动填充。

连接配置、SSH 密码/私钥口令、模型配置和 API Key 本版均不持久化。无法承诺托管字符串可从内存立即清零；需要抵御同用户恶意进程时需额外的操作系统隔离。

## 源码构建与测试

需要 .NET 10 SDK、Node.js 20+、npm，以及 NuGet/npm 包源访问能力。

```powershell
./build.ps1 -Test
# 可选：随包包含 .NET Runtime
./build.ps1 -Test -SelfContained
```

产物为 `dist/FeatherShell/` 和 `dist/FeatherShell-0.2.0-win-x64.zip`。

测试通过 Node ssh2 启动仅监听 127.0.0.1 的临时 SSH 服务，使用固定的测试账号与内存生成的主机密钥。测试不会访问用户真实服务器。覆盖主机信任、错误认证、参数注入、目标授权、敏感输出投影、超量输出、撤销授权和审计内容。测试文件写入 `test-artifacts/`，不提交版本库。

尚需用户在真实 Linux 环境验证密码/加密私钥认证、中文与全屏终端、不同 systemd unit 以及所用模型服务的工具调用兼容性。不能以模拟服务测试替代真实环境验收。

## 图标

沿用用户现有 FeatherPen 羽毛图标作为编辑参考，使用内置 imagegen 工具生成 FeatherShell 配色版本；图标文件在 `assets/`。提示词见 `assets/icon-prompt.txt`。

源码当前未指定开源许可；公开仓库不自动赋予第三方再分发权。原始羽毛图标的使用权由项目维护者确认。第三方组件遵循各自许可。
