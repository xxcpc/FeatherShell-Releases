'use strict';
const term = new Terminal({fontFamily:'Cascadia Mono, Consolas, monospace',fontSize:14,cursorBlink:true,scrollback:5000,allowProposedApi:false,allowWindowTitleChange:false,theme:{background:'#0d131b',foreground:'#d6e2ec',cursor:'#58d9bd',selectionBackground:'#25473f',green:'#58d9bd',cyan:'#65c5d8'}});
const fit = new FitAddon.FitAddon(); term.loadAddon(fit); term.open(document.getElementById('terminal'));
const send = value => window.chrome.webview.postMessage(value);
term.onData(text => send({kind:'input',text}));
term.onResize(({cols,rows}) => send({kind:'resize',cols,rows}));
// No web-links addon, clipboard OSC handler, host objects or dynamic script evaluation.
window.chrome.webview.addEventListener('message', event => {const m=event.data;if(m.kind==='output'&&typeof m.base64==='string'){const b=atob(m.base64);term.write(Uint8Array.from(b,c=>c.charCodeAt(0)));}});
new ResizeObserver(()=>{if(document.body.clientWidth>30)fit.fit();}).observe(document.getElementById('terminal'));
fit.fit();send({kind:'ready'});term.focus();
