# Third-party components

FeatherShell uses the following components. Their original licenses apply; bundled license copies are in `licenses/`.

| Component | Version | License | Source |
|---|---|---|---|
| SSH.NET | 2026.0.0 | MIT | https://github.com/sshnet/SSH.NET |
| BouncyCastle.Cryptography | transitive; see packages.lock.json | MIT | https://github.com/bcgit/bc-csharp |
| Microsoft.Web.WebView2 SDK | 1.0.4314.35 | Microsoft license | https://www.nuget.org/packages/Microsoft.Web.WebView2 |
| xterm.js | 5.5.0 | MIT | https://github.com/xtermjs/xterm.js |
| @xterm/addon-fit | 0.10.0 | MIT | https://github.com/xtermjs/xterm.js |
| ssh2 (development tests only) | see package-lock.json | MIT | https://github.com/mscdex/ssh2 |

.NET and Windows desktop frameworks remain subject to Microsoft's applicable terms. WebView2 Runtime is installed separately. An optional self-contained build includes .NET runtime files with their notices. NuGet transitive Microsoft.Extensions components retain their own MIT licenses and notices.
